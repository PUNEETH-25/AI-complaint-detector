# HACKNETIX frontend (Flask + Jinja + vanilla JS)

No build step, no npm. Drop into your Flask project.

## Install
1. Copy `templates/*` into your Flask `templates/` (back up your old ones first).
2. Copy `static/css/hacknetix.css` and `static/js/app.js` into your `static/`.
3. Merge `frontend_routes.py` into your app and swap in your own auth decorators.
4. `base.html` expects `current_user` (Flask-Login style) with `.is_authenticated` and `.role`
   (`staff` / `admin`). Edit the two lines at the top of `<body>` if yours differ.
5. Run `flask run` and open `/`.

## JSON endpoints the pages call
The UI never hard-codes data. If your existing endpoints have different paths or
field names, change them in one place (the `API.get(...)` call in each template's script).

| Page | Endpoint | Expected shape |
|---|---|---|
| Landing | `GET /api/stats` | `{complaints, groups, resolved, organizations, is_sample}` |
| Select org | `GET /api/organizations?sector=&q=` | `{items:[{id,name,sector,city,locations[]}]}` |
| Dashboard | `GET /api/dashboard?org=` | `{organization,user,is_sample,counts{mine,open,in_progress,resolved},recent[],common_issues[],faqs[],announcements[],notifications[]}` |
| Raise | `GET /api/categories`, `POST /api/complaints` (multipart: category,title,description,location,severity,image,organization_id) | `201 {id}` |
| Analysis | `GET /api/complaints/<id>/analysis` | `{status,priority,matches:[{group_id,group_title,title,score 0-1,location}]}` |
| My complaints | `GET /api/complaints?q=&status=&priority=&category=&days=&mine=1` | `{items:[...]}` |
| Detail | `GET /api/complaints/<id>`, `POST .../feedback`, `POST .../reopen` | see comments in template |
| Notifications | `GET /api/notifications[?unread=1]`, `POST /api/notifications/read` | `{items[], unread_count}` |
| Staff | `GET /api/staff/summary`, `/api/staff/groups`, `/api/staff/suggestions`, `POST /api/staff/suggestions/<id>/confirm\|reject` | see comments |
| Group | `GET/PATCH /api/groups/<id>` | see comments |

Status values used: `Submitted`, `Under AI Analysis`, `Awaiting Staff Review`, `In Progress`, `Resolved`.
Priority values: `high`, `medium`, `low`.

## Notes
- Access control stays on the server. The UI hides nothing for security; your endpoints must enforce role and organization.
- Similarity is shown as a descriptive score with an explicit "not a probability / staff must confirm" note.
- Statistics render only what `/api/stats` and `/api/dashboard` return; set `is_sample: true` to show a "Sample statistics" label.
- Design tokens (colors, spacing, radii, shadows) are CSS variables at the top of `hacknetix.css`.
- Respects `prefers-reduced-motion`; animation never blocks submit.
