Put your all-MiniLM-L6-v2 here, either as:
  - the .zip file (it is extracted automatically on first start), or
  - the unzipped folder (it must contain modules.json, or config.json + tokenizer files).
The app never downloads anything. If the model is missing it refuses to start.
