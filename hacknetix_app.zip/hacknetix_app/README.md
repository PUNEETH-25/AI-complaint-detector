# HACKNETIX: Flask backend + frontend + local MiniLM

One runnable project: the redesigned frontend (`templates/`, `static/`), a Flask + SQLAlchemy + SQLite
backend, and your local `all-MiniLM-L6-v2` model for semantic similarity.

## Run it
```bash
python -m venv .venv && source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 1. Put your model zip (or the unzipped folder) into ml_model/   (zip is extracted automatically)
# 2. Create tables + REVA University, Bengaluru
flask --app app seed
# 3. Create a staff account for REVA (staff are never self-registered)
flask --app app create-staff --org-id 1
# 4. Start
flask --app app run --debug          # http://127.0.0.1:5000
```
Check the model: `flask --app app model-info` should print `all-MiniLM-L6-v2 (dim=384)`.
Students register themselves at `/register`. Optional sample data: `flask --app app seed --demo`
(the UI then labels statistics as sample data).

Production: `waitress-serve --call --threads=4 app:create_app` (one process only: the model lives in memory).

## How the ML connects
1. A complaint is saved first, so it is never lost.
2. `similarity.py` encodes `title + description` with your local MiniLM (offline, CPU).
3. Cosine similarity is computed against complaints in the SAME organization that sit in other groups.
   Groups at or above the threshold (0.60 default) become `Suggestion` rows (max 5).
4. Nothing is merged automatically. Staff Confirm or Reject on the staff pages. Confirm moves the complaint
   into the group; every individual complaint is preserved. Scores are shown as "similarity", never probability.
5. Embeddings are stored with the model name. If you ever change model, run `flask --app app reindex`.
6. If the model cannot be loaded the app refuses to start with a clear message (no silent downgrade).
   `ALLOW_FALLBACK_EMBEDDER=1` is a development-only stand-in and is NOT MiniLM.

## Roles and access control
- `user`: sees only their own complaints (other IDs return 404) and only their own organization.
- `staff`: scoped to their organization; reviews suggestions, changes status/priority, adds notes.
- `admin`: all organizations. Create with `flask --app app create-admin`.
- Flask-Login sessions, hashed passwords, CSRF token on every POST/PATCH, login throttling,
  upload type sniffing (PNG/JPG/WebP, 5 MB) and access-checked image serving.
- Members of an organization can see the titles of issue groups in it (shown as "common issues" and as
  AI match headlines). Descriptions and other people's complaints stay private.

## Your existing database
This backend defines its own schema (`db_models.py`) and creates it with `db.create_all()`.
It does NOT migrate an older HACKNETIX database. Point `DATABASE_URL` at a fresh file, or adapt the
models to your old table and column names.

## Tests
`python -m pytest -q tests` runs the full journey (register, submit, AI suggestion, staff confirm,
status updates, feedback, reopen, cross-organization access) with the development fallback embedder.
`HX_TEST_REAL_MODEL=1 python -m pytest -q tests` uses your real model.

## Endpoint map
Pages: `/ /organizations /dashboard /complaints/new /complaints/<id>/analysis /my-complaints /complaints/<id> /notifications /staff /staff/groups/<id> /login /register /logout`

API (JSON): `/api/stats /organizations /categories /dashboard /complaints /complaints/<id> /complaints/<id>/analysis /complaints/<id>/image /complaints/<id>/feedback /complaints/<id>/reopen /notifications /notifications/read /staff/summary /staff/groups /staff/suggestions /staff/suggestions/<id>/confirm|reject /groups/<id> (GET, PATCH) /staff/announcements /health`

CLI: `seed [--demo] add-org create-staff create-admin reanalyze reindex model-info`
