"""
Page routes for the HACKNETIX frontend.

Merge into your existing Flask app (or register as a Blueprint). These routes ONLY
render templates. All data comes from your existing JSON endpoints, so SQLite,
SQLAlchemy, auth and the local all-MiniLM-L6-v2 similarity logic stay untouched.

Replace `login_required` / `staff_required` with your existing decorators.
"""
from flask import Blueprint, render_template

# from your_app.auth import login_required, staff_required   # <-- use your own
def login_required(f): return f
def staff_required(f): return f

ui = Blueprint("ui", __name__)


@ui.route("/")
def landing():            return render_template("landing.html")

@ui.route("/organizations")
def organizations():      return render_template("select_org.html")

@ui.route("/dashboard")
@login_required
def dashboard():          return render_template("dashboard.html")

@ui.route("/complaints/new")
@login_required
def new_complaint():      return render_template("raise_complaint.html")

@ui.route("/complaints/<cid>/analysis")
@login_required
def analysis(cid):        return render_template("analysis.html")

@ui.route("/my-complaints")
@login_required
def my_complaints():      return render_template("my_complaints.html")

@ui.route("/complaints/<cid>")
@login_required
def complaint_detail(cid): return render_template("complaint_detail.html")

@ui.route("/notifications")
@login_required
def notifications():      return render_template("notifications.html")

@ui.route("/staff")
@login_required
@staff_required
def staff():              return render_template("staff_dashboard.html")

@ui.route("/staff/groups/<gid>")
@login_required
@staff_required
def group_detail(gid):    return render_template("group_detail.html")

# app.register_blueprint(ui)
